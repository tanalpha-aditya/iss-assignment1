#!/bin/bash
awk '/a/{++cnt} END {print "Count = ", cnt}' $1

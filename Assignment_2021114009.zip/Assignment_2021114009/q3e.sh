#!/bin/bash
grep -o '[[:alnum:]]*' $1 | awk '{ count[$0]++; next}END {ORS=" "; for (x in count)print" Word:" x " - Count of repetition: "count[x] "\n"}'
echo

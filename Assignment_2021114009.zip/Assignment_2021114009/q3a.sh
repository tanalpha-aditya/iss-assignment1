#!/bin/bash
stat -f%z $1

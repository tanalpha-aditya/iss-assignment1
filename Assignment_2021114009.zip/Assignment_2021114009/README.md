Below are instruction to run any Program.
And i ran these code in Apple Mac M1.

INPUT FORMAT:

    q1a.sh
        chmod +x q1a.sh
        ./q1a.sh
        
    q1b.sh
        chmod +x q1b.sh
        ./q1b.sh
        
    q2.sh
        chmod +x q2.sh
        ./q2.sh

    q3a.sh
        chmod +x q3a.sh
        ./q3a.sh <input file>
        
    q3b.sh
        chmod +x q3b.sh
        ./q3b.sh <input file>
        
    q3c.sh
        chmod +x q3c.sh
        ./q3c.sh <input file>

    q3d.sh
        chmod +x q3d.sh
        ./q3d.sh <input file>
        
    q3e.sh
        chmod +x q3e.sh
        ./q3e.sh <input file>

    q4.sh
        chmod +x q4.sh
        ./q4.sh
        <input file>
        
    q5.sh
        chmod +x q5.sh
        ./q5.sh
        <input string>
        

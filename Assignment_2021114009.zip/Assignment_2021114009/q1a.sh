#!/bin/bash

sed '/^$/d' quotes.txt
echo

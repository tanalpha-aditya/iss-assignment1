#!/bin/bash
wc -w <$1

#!/bin/bash
awk '{OFS = "";print "Line No: <",NR,"> - ",NF}' $1 >> q3.txt

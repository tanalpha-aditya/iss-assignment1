#!/bin/bash

sort quotes.txt | uniq -u
echo

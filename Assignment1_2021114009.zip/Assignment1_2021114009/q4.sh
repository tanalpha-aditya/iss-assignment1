#!/bin/bash

IFS=","
read -a input

for((i=0 ; i<${#input[*]} ; i++))
do
    for((j=i+1 ; j<${#input[*]} ; j++))
    do
        if [ ${input[$i]} -gt ${input[$j]} ]
        then
            temp=${input[$j]}
            input[$j]=${input[$i]}
            input[$i]=$temp
        fi
    done
done

for i in ${input[@]}
do
    echo -n "$i,"
done
echo

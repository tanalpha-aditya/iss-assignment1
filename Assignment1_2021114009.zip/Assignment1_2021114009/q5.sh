read s
revstr=`echo $s | rev`
echo "Original String : $s"
echo "Reversed String : $revstr"


#read s
#revstr=`echo $s | rev`
name=$(echo "$revstr" | tr "A-Za-z" "B-ZAb-za")
#echo $name
#echo "Original String : $s"
echo "Reversed subsequent string : $name"

#read s
#revstr=`echo $s | rev`
#echo "Original String : $s"
#echo "Reversed String : $revstr"

len=${#s}
lenf=`expr $len/2`

echo " first half reversed -" ${revstr:lenf:len}${s:lenf:len}
#echo ${s:lenf+1:len}
